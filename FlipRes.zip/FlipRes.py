
bl_info = {
    "name": "FlipRes: Switch and Resize Render Resolution",
    "blender": (2, 80, 0),
    "category": "Render"
}

import bpy

# Operator to switch the resolution
class RENDER_OT_switch_resolution(bpy.types.Operator):
    bl_idname = "render.switch_resolution"
    bl_label = "Switch X and Y"
    bl_description = "Switch Render Resolution X and Y values"
    
    def execute(self, context):
        render = context.scene.render
        render.resolution_x, render.resolution_y = render.resolution_y, render.resolution_x
        return {'FINISHED'}

# Operator to double the resolution
class RENDER_OT_double_resolution(bpy.types.Operator):
    bl_idname = "render.double_resolution"
    bl_label = "Double Resolution (x2)"
    bl_description = "Double Render Resolution X and Y values"
    
    def execute(self, context):
        render = context.scene.render
        render.resolution_x *= 2
        render.resolution_y *= 2
        return {'FINISHED'}

# Operator to halve the resolution
class RENDER_OT_half_resolution(bpy.types.Operator):
    bl_idname = "render.half_resolution"
    bl_label = "Halve Resolution (1/2)"
    bl_description = "Halve Render Resolution X and Y values"
    
    def execute(self, context):
        render = context.scene.render
        render.resolution_x //= 2
        render.resolution_y //= 2
        return {'FINISHED'}

# Panel to add the buttons in Output Properties
class RENDER_PT_switch_resolution(bpy.types.Panel):
    bl_label = "Resolution Tools"
    bl_idname = "RENDER_PT_switch_resolution"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "output"
    
    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        # Switch button
        row.operator("render.switch_resolution", text="Switch X and Y")
        
        # Add Double and Half buttons
        row = layout.row(align=True)
        row.operator("render.double_resolution", text="x2")
        row.operator("render.half_resolution", text="1/2")

# Register and Unregister
def register():
    bpy.utils.register_class(RENDER_OT_switch_resolution)
    bpy.utils.register_class(RENDER_OT_double_resolution)
    bpy.utils.register_class(RENDER_OT_half_resolution)
    bpy.utils.register_class(RENDER_PT_switch_resolution)

def unregister():
    bpy.utils.unregister_class(RENDER_OT_switch_resolution)
    bpy.utils.unregister_class(RENDER_OT_double_resolution)
    bpy.utils.unregister_class(RENDER_OT_half_resolution)
    bpy.utils.unregister_class(RENDER_PT_switch_resolution)

if __name__ == "__main__":
    register()
